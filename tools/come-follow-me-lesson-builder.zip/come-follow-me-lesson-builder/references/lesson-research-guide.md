# Lesson Research Guide

Deeper guidance for the research behind each handout. Read this before researching a lesson.

## Table of contents
1. Locating the official Come, Follow Me outline
2. Building the historical summary
3. Building scripture parallels (and adapting by curriculum year)
4. Latter-day connections worth pulling
5. Handling difficult passages

---

## 1. Locating the official Come, Follow Me outline

The curriculum rotates on a four-year cycle and the manuals are re-edited, so the *current year's* outline is the only reliable source. Use the actual current date to decide the year and volume:

- Old Testament, New Testament, Book of Mormon, Doctrine and Covenants — one per year, repeating.

**Find it:**
- Search something like `Come Follow Me [current year] [scripture range]` or `Come Follow Me [current year] [month day]`.
- The official manual lives at `churchofjesuschrist.org` under a path like
  `/study/manual/come-follow-me-for-home-and-church-[volume]-[year]/[week-number]`.
- Fetch that page directly. Aggregator and podcast sites are fine for extra ideas but are **not** the authority.

**Extract and record:**
- The outline **title** (often a scripture phrase, e.g., "There Is a Prophet in Israel").
- The **week's date range** and the exact **scripture block**.
- Each **principle heading** (these are the doctrinal spine of the week).
- The **verses cited** under each principle, and any **Scripture Helps** questions.
- The **"Ideas for Teaching Children"** and any youth/seminary ideas.
- **Cross-references** the outline itself gives (Book of Mormon, Doctrine and Covenants, New Testament) and any **general-conference talks** or **Bible Dictionary** entries it links.

Section 4 of the handout must mirror what you actually found here — not a generic take.

---

## 2. Building the historical summary

Aim for context that makes the passage vivid and credible, not a textbook dump. For a given block, establish:

- **When:** approximate dates and the era (e.g., divided-kingdom Israel, Roman-occupied Judea, Nephite reign-of-the-judges).
- **Who's in power:** the dynasty, king, empire, or civilization, and the political pressures of the moment.
- **Where:** geography that matters to the story (elevation, rivers, trade routes, distances, neighboring peoples).
- **Culture:** customs, worship practices, laws, or social structures the text assumes the reader knows.
- **Concrete anchors:** one or two artifacts, inscriptions, or archaeological finds that touch the passage. These make history feel real to students. Examples of the *kind* of anchor to look for: royal steles and inscriptions, city excavations, mentions of biblical figures in foreign records.

Verify names and dates across at least two reputable sources. Prefer scholarly and encyclopedic sources; treat any single site with caution. Cite what you use in your own notes so the handout's claims are grounded.

---

## 3. Building scripture parallels

Parallels land when they rest on a **shared doctrinal pattern**, not a surface coincidence. Identify the pattern in the passage first, then find its scriptural echo.

Common patterns to look for:
- **Translation / not tasting death** (e.g., Elijah, Enoch, the Three Nephites, John the Beloved).
- **Prophetic succession / authority conferred** (mantle passing; keys handed on).
- **Miracles as types of Christ** — giving life, healing, feeding, calming, cleansing.
- **Covenant and cleansing** (waters, temples, sacrifice, baptism).
- **Deliverance** — God saving a people against impossible odds.
- **Apostasy and restoration / a faithful remnant** preserved.
- **The prophet as a people's true strength** over armies and kings.

For each parallel, record three things: the **passage detail**, the **scriptural echo (book and verse)**, and a plain **"what it teaches."** This maps directly onto the handout's three-part parallel cards.

**Adapt by curriculum year:**
- **Old / New Testament year:** draw **Book of Mormon** parallels (the default, and the most requested).
- **Book of Mormon year:** draw connections to the **Bible** and **Doctrine and Covenants** instead — the Book of Mormon passage is the primary text, so parallels flow outward from it.
- **Doctrine and Covenants year:** connect to **Bible and Book of Mormon** precedents and to Restoration history.

Keep parallels honest — if a link is a stretch, drop it. Five strong parallels beat ten thin ones.

---

## 4. Latter-day connections worth pulling

Where they genuinely illuminate the text:
- The **Bible Dictionary** entry for a key figure or place (often has doctrinal notes specific to the Church).
- **Doctrine and Covenants** sections tied to the passage (e.g., D&C 110 for Elijah and the sealing keys).
- **Temple / Restoration** links — priesthood keys, ordinances, covenants.
- The **general-conference talks** the official outline cites (quote briefly, cite fully).

These belong in Section 4, supporting the week's principles.

---

## 5. Handling difficult passages

Some passages raise hard questions (violence, judgment, unfamiliar customs). Do not skip or sensationalize them. Give the teacher what they need:

- Explain the **original-language or cultural context** that reframes a shocking detail (e.g., a Hebrew word's real range of meaning).
- Note the **covenant or theological logic** the text is working within.
- Offer a **constructive discussion angle** for the audience rather than leaving it raw.

The goal is to equip a teacher to answer a student's "wait, why did that happen?" with confidence and faith.
