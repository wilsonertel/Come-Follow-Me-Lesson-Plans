# Lesson Research Guide

Deeper guidance for the research behind each handout. Read this before researching a lesson.

## Table of contents
1. Locating the official Come, Follow Me outline
2. Building the historical summary
3. Building scripture parallels (and adapting by curriculum year)
4. Latter-day connections worth pulling
5. Handling difficult passages
6. Linking scripture references (URL recipe)

---

## 1. Locating the official Come, Follow Me outline

The curriculum rotates on a four-year cycle and the manuals are re-edited, so the *current year's* outline is the only reliable source. Use the actual current date to decide the year and volume:

- Old Testament, New Testament, Book of Mormon, Doctrine and Covenants — one per year, repeating.

**Find it:**
- Search something like `Come Follow Me [current year] [scripture range]` or `Come Follow Me [current year] [month day]`.
- The official manual lives at `churchofjesuschrist.org` under a path like
  `/study/manual/come-follow-me-for-home-and-church-[volume]-[year]/[week-number]`.
- Fetch that page directly. Aggregator and podcast sites are fine for extra ideas but are **not** the authority.

**Extract and record:**
- The outline **title** (often a scripture phrase, e.g., "There Is a Prophet in Israel").
- The **week's date range** and the exact **scripture block**.
- Each **principle heading** (these are the doctrinal spine of the week).
- The **verses cited** under each principle, and any **Scripture Helps** questions.
- The **"Ideas for Teaching Children"** and any youth/seminary ideas.
- **Cross-references** the outline itself gives (Book of Mormon, Doctrine and Covenants, New Testament) and any **general-conference talks** or **Bible Dictionary** entries it links.

Section 4 of the handout must mirror what you actually found here — not a generic take.

---

## 2. Building the historical summary

Aim for context that makes the passage vivid and credible, not a textbook dump. For a given block, establish:

- **When:** approximate dates and the era (e.g., divided-kingdom Israel, Roman-occupied Judea, Nephite reign-of-the-judges).
- **Who's in power:** the dynasty, king, empire, or civilization, and the political pressures of the moment.
- **Where:** geography that matters to the story (elevation, rivers, trade routes, distances, neighboring peoples).
- **Culture:** customs, worship practices, laws, or social structures the text assumes the reader knows.
- **Concrete anchors:** one or two artifacts, inscriptions, or archaeological finds that touch the passage. These make history feel real to students. Examples of the *kind* of anchor to look for: royal steles and inscriptions, city excavations, mentions of biblical figures in foreign records.

Verify names and dates across at least two reputable sources. Prefer scholarly and encyclopedic sources; treat any single site with caution. Cite what you use in your own notes so the handout's claims are grounded.

---

## 3. Building scripture parallels

Parallels land when they rest on a **shared doctrinal pattern**, not a surface coincidence. Identify the pattern in the passage first, then find its scriptural echo.

Common patterns to look for:
- **Translation / not tasting death** (e.g., Elijah, Enoch, the Three Nephites, John the Beloved).
- **Prophetic succession / authority conferred** (mantle passing; keys handed on).
- **Miracles as types of Christ** — giving life, healing, feeding, calming, cleansing.
- **Covenant and cleansing** (waters, temples, sacrifice, baptism).
- **Deliverance** — God saving a people against impossible odds.
- **Apostasy and restoration / a faithful remnant** preserved.
- **The prophet as a people's true strength** over armies and kings.

For each parallel, record three things: the **passage detail**, the **scriptural echo (book and verse)**, and a plain **"what it teaches."** This maps directly onto the handout's three-part parallel cards.

**Adapt by curriculum year:**
- **Old / New Testament year:** draw **Book of Mormon** parallels (the default, and the most requested).
- **Book of Mormon year:** draw connections to the **Bible** and **Doctrine and Covenants** instead — the Book of Mormon passage is the primary text, so parallels flow outward from it.
- **Doctrine and Covenants year:** connect to **Bible and Book of Mormon** precedents and to Restoration history.

Keep parallels honest — if a link is a stretch, drop it. Five strong parallels beat ten thin ones.

---

## 4. Latter-day connections worth pulling

Where they genuinely illuminate the text:
- The **Bible Dictionary** entry for a key figure or place (often has doctrinal notes specific to the Church).
- **Doctrine and Covenants** sections tied to the passage (e.g., D&C 110 for Elijah and the sealing keys).
- **Temple / Restoration** links — priesthood keys, ordinances, covenants.
- The **general-conference talks** the official outline cites (quote briefly, cite fully).

These belong in Section 4, supporting the week's principles.

---

## 5. Handling difficult passages

Some passages raise hard questions (violence, judgment, unfamiliar customs). Do not skip or sensationalize them. Give the teacher what they need:

- Explain the **original-language or cultural context** that reframes a shocking detail (e.g., a Hebrew word's real range of meaning).
- Note the **covenant or theological logic** the text is working within.
- Offer a **constructive discussion angle** for the audience rather than leaving it raw.

The goal is to equip a teacher to answer a student's "wait, why did that happen?" with confidence and faith.

---

## 6. Linking scripture references (URL recipe)

Every scripture reference in the handout is a link to the official text. Use the Church's `/study/` URLs — they are **universal links**, so on a phone or tablet with Gospel Library installed they open the passage in the app, and on a computer they open the website. One href covers both. Do **not** use `gospellibrary://` scheme URLs: they do nothing on desktop and dead-end for anyone without the app.

### The shape of the URL

```
https://www.churchofjesuschrist.org/study/scriptures/{volume}/{book}/{chapter}?lang=eng&id={anchor}#{first}
```

Rendered in the handout (note `&amp;` for the ampersand inside an HTML attribute):

```html
<a class="sref" target="_blank" rel="noopener"
   href="https://www.churchofjesuschrist.org/study/scriptures/ot/2-chr/26?lang=eng&amp;id=p15-p16#p15">26:15–16</a>
```

### Verse anchors

Verses are `p`-numbered. The `id` selects what gets highlighted; the `#` fragment scrolls to the first one.

| Reference | `id=` … `#` |
|---|---|
| A single verse — 26:5 | `id=p5#p5` |
| A range — 26:15–16 | `id=p15-p16#p15` |
| Discrete verses — 26:1, 3 | `id=p1,p3#p1` |
| A whole chapter — Leviticus 13 | omit `id` and the fragment entirely |
| A multi-chapter span — Helaman 8–9 | link the first chapter, no `id` |

### Volumes

`ot` · `nt` · `bofm` · `dc-testament` · `pgp`

Doctrine and Covenants sections sit under `dc-testament/dc/{section}`; Official Declarations under `dc-testament/od/{number}`. Pearl of Great Price books are `pgp/moses`, `pgp/abr`, `pgp/js-m`, `pgp/js-h`, `pgp/a-of-f`.

### Book abbreviations

**Old Testament** (`ot/`) — gen, ex, lev, num, deut, josh, judg, ruth, 1-sam, 2-sam, 1-kgs, 2-kgs, 1-chr, 2-chr, ezra, neh, esth, job, ps, prov, eccl, isa, jer, lam, ezek, dan, hosea, joel, amos, obad, jonah, micah, nahum, hab, zeph, hag, zech, mal

**New Testament** (`nt/`) — matt, mark, luke, john, acts, rom, 1-cor, 2-cor, gal, eph, col, 1-tim, 2-tim, titus, philem, heb, james, 1-pet, 2-pet, 1-jn, 2-jn, 3-jn, jude, rev

**Book of Mormon** (`bofm/`) — 1-ne, 2-ne, jacob, enos, jarom, omni, mosiah, alma, hel, 3-ne, 4-ne, morm, ether, moro

The pattern is the standard citation abbreviation, lowercased, with spaces and periods replaced by hyphens. A few books aren't in the lists above (Song of Solomon, Philippians, Thessalonians, Words of Mormon) — **verify those rather than guessing**: fetch the URL you plan to use, and if it 404s, search churchofjesuschrist.org for the chapter and copy the path from the result. A wrong abbreviation is a dead link in a teacher's hands during class.

### Also worth linking

- **Hymns** — `https://www.churchofjesuschrist.org/study/manual/hymns/{hymn-slug}?lang=eng` (e.g. `be-thou-humble`).
- **The week's outline** — link the specific week's page if you have its URL from Step 1; otherwise link the manual's landing page rather than guessing at a week number.

### Sweep before delivering

Read back through the finished handout and confirm nothing was missed. Easy things to overlook: bare in-chapter references (`v. 16`, `vv. 6–15`), the `.vv` labels on summary steps, the second `.mini` label on a parallel card, references buried inside teaching ideas, and the footer's sources note.
