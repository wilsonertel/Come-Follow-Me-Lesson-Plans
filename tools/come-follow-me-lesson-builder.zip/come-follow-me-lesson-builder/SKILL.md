---
name: come-follow-me-lesson-builder
description: Build a complete Come, Follow Me lesson-prep packet for a block of scripture, with four parts in a fixed order — a historical summary of the period, a chapter or passage summary, Book of Mormon parallels (or cross-scripture connections in a Book of Mormon or Doctrine and Covenants year), and a tie-back to that week's official Come, Follow Me outline. Deliver it as a polished, print-ready visual HTML handout, and offer a Word-doc version too. Use this whenever the user asks for a Come, Follow Me lesson, a Sunday School, seminary, Primary, or Gospel Doctrine handout or summary, a scripture deep dive or study notes, lesson prep for a specific week or scripture range, Book of Mormon parallels to a Bible passage, or teaching helps for members of The Church of Jesus Christ of Latter-day Saints — even if they never say the word skill or handout. Always pull the current week's official outline from churchofjesuschrist.org instead of relying on memory, since the curriculum rotates yearly and is updated.
---

# Come, Follow Me Lesson Builder

Produce a thorough, teachable, visually engaging lesson-prep packet for a block of scripture, tied to the official Come, Follow Me curriculum. The finished product is a self-contained HTML handout the teacher can read on screen or print for class.

## What you produce

A single handout with **four sections, always in this order**:

1. **Historical Summary of the Period** — the world behind the text: dates, era, kingdoms/dynasties or civilizations, key figures, geography, culture, and any artifacts or archaeology that make it concrete.
2. **Chapter / Passage Summary** — a clear walk through the passage, scene by scene or teaching by teaching, surfacing what actually happens and why it matters.
3. **Scripture Parallels** — for a Bible study year, **Book of Mormon parallels**; for a Book of Mormon or Doctrine and Covenants year, **cross-scripture connections** (Bible, Restoration scripture). Each parallel gets a one-line "what it teaches" takeaway.
4. **Tie to Come, Follow Me** — how the passage supports that week's official outline: the outline title/theme, the principles it highlights, the verses and Scripture Helps questions it cites, relevant latter-day connections (Bible Dictionary, Doctrine and Covenants, temple/Restoration ties, cited general-conference talks), and concrete teaching ideas for the intended audience.

Do not drop information to make room for visuals. The handout should be **both** complete **and** attractive.

## Workflow

### Step 1 — Pin down the lesson and the week

Establish two things: the **scripture block** and the **Come, Follow Me week** it belongs to.

- If given a scripture range (e.g., "2 Kings 2–7"), find which weekly outline covers it.
- If given a date or "this week," find the scripture block for that week.
- The curriculum runs on a four-year rotation (Old Testament, New Testament, Book of Mormon, Doctrine and Covenants). Use the actual current date to determine the year and volume — never assume from memory.

**Always fetch the official outline** from churchofjesuschrist.org for the current Come, Follow Me year. Search for it, then fetch the page and extract: the outline **title**, each **principle heading**, the **verses cited** under each principle, the **Scripture Helps** questions, the **"Ideas for Teaching Children"/youth** ideas, and any **general-conference talks or Bible Dictionary entries** referenced. This is the backbone of Section 4, so get it right. See `references/lesson-research-guide.md` for how to locate it reliably and what to pull.

### Step 2 — Confirm audience and scope

Default audience: **youth Sunday School (ages 12–13)**. Adapt tone and teaching ideas if the user indicates Primary (children), seminary (teens), Gospel Doctrine (adults), or personal study. If the block spans several chapters, ask whether they want one combined packet or one chapter at a time (chapter-at-a-time usually teaches better). Infer from context when you can and state your assumption rather than over-asking.

### Step 3 — Research each section

Do real research; don't fill from memory alone.

- **History:** web-search reputable sources for the period. Nail down dates, the ruling era/dynasty or civilization, geography, culture, and one or two concrete anchors (an inscription, stele, city, or custom) that make it vivid. Verify names and dates across sources.
- **Summary:** read the passage closely; identify its structure (narrative movements, or a set of teachings/miracles) and the turning points.
- **Parallels:** ground every parallel in a **real doctrinal pattern** (translation, prophetic succession, miracles as types of Christ, covenant, deliverance, apostasy/restoration, etc.), then map it to its scriptural analogue with book-and-verse. Give each a plain takeaway.
- **Latter-day connections:** pull the Bible Dictionary entry, relevant Doctrine and Covenants sections, temple/Restoration links, and the conference talks the outline cites — but only where they genuinely illuminate the passage.

Guidance and worked patterns are in `references/lesson-research-guide.md`. Read it before researching.

### Step 4 — Build the visual handout

Build a single self-contained HTML file from `assets/handout-template.html`. That file carries the full component system (hero, at-a-glance band, numbered summary timeline, color-coded parallel cards, teaching-ideas checklist, callouts, pull-quotes, print button) and a robust reveal-with-fallback so **content is never left hidden**.

Design principles:

- **Derive the visual motif from the passage's own imagery.** Do not reuse one fixed look. Chapter 2 of 2 Kings suggested fire and a night sky (the chariot of fire, the ascent); a temple chapter might suggest stone and gold; a wilderness chapter, sand and water. Pick a palette and one signature element from the text itself, and set the template's design tokens accordingly.
- **Keep the four-section structure and numbering.**
- **Preserve every fact** from your research.
- **Make it print-friendly** and responsive; keep the print button.
- Save the file to the outputs directory and present it as an artifact.

If the user wants a Word version, also generate a `.docx` using the `docx` skill, mirroring the same four sections.

## Accuracy and sensitivity

- Treat the **official outline as the authority** for the week's themes; build Section 4 around it, not around your own priorities.
- **Paraphrase**; keep any scripture quotation short. King James Version and Book of Mormon text may be quoted briefly with the reference.
- Represent Latter-day Saint doctrine faithfully and **cite** sources (scripture references, Bible Dictionary, conference talks). Do not invent facts, references, or quotations.
- Handle **difficult passages** honestly, with scholarly context, framed constructively for the audience rather than sensationalized. Give teachers the background to answer hard questions.
- Match reading level and examples to the audience; for youth and children keep it clear, concrete, and age-appropriate.

## Quality check before delivering

- All four sections present, in order, and complete.
- Section 4 reflects the **actual current outline** you fetched (correct title, principles, cited verses, questions).
- Historical claims verified; no invented references.
- Parallels each have a scriptural anchor and a takeaway.
- Handout opens cleanly, is responsive, prints well, and hides no content.
- Teaching ideas fit the stated audience.

## Reference files

- `references/lesson-research-guide.md` — how to find the official outline, build solid historical context, and construct scripture parallels (with adaptation for Book of Mormon and Doctrine and Covenants years, and handling hard passages). Read before Step 1's research.
- `assets/handout-template.html` — the reusable HTML scaffold and design system. Copy and fill it in Step 4; customize the design tokens to the lesson's motif.
